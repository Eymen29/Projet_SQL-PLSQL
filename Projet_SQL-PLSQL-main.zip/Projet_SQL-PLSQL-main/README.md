# Projet_SQL-PLSQL

author : MAHDJOUBI Bilal, H'MIDA Eymen <br/>
Date : Mai 2020

Outil Utilisé : Oracle Live SQL <br/>
Projet consistant a créer des bases via le language SQL puis a les manipuler via la création de procédure PLSQL. <br/>

Compétences Utilisées : <br/>
-SQL<br/>
-PLSQL<br/>
-Oracle Live SQL<br/>


